<?php 

/**
 * Component Model
 * @category  Model
 */
class ComponentsController extends BaseController{
	
}
