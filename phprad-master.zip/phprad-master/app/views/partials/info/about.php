<div class="container">
	<h4>About</h4>
	<hr />
	<div>
		<p>Put page content here.</p>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/about.php</i></small>
	</div>
</div>


